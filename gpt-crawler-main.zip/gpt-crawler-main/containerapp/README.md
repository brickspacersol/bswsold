# Containerized crawler

## Docker image with packaged crawler, with script for building and execution.

All dependencies set up and configured in the Dockerfile. Requires docker to be installed.

## Get started

### Prerequisites

Be sure you have docker installed

1. `cd gpt-crawler/containerapp `
2. `. ./run.sh `
